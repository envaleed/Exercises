from app import app, db
from flask import jsonify, Response, Flask, request, abort, make_response
from flask_httpauth import HTTPBasicAuth
from app import app

auth = HTTPBasicAuth()

@auth.error_handler
def unauthorized():
    return make_response(jsonify({'error':'Unauthorized access'}),403)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error':'Not found'}))